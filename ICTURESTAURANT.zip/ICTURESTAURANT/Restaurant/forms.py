from django import forms
class commandeForm(forms.Form):
    quantite = forms.IntegerField(min_value=1, label='Quantite')