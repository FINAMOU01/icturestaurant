from typing import Any
from django.db import models

# Create your models here.
class Plat(models.Model):
    nom=models.CharField(max_length=100)
    description=models.TextField()
    prix=models.DecimalField(max_digits=6, decimal_places=0)
    disponible=models.BooleanField(default=True)
    image = models.ImageField(upload_to='plats/')
    
   

    def __str__(self):
        return self.nom
    
class Menu(models.Model):
    nom=models.CharField(max_length=100)
    plats=models.ManyToManyField(Plat)
    def __str__(self):
        return self.nom
class commande(models.Model):
    plat = models.ForeignKey(Plat, on_delete=models.CASCADE)
    quantite = models.PositiveIntegerField()
    nom_client = models.CharField(max_length=100 ,default='client')
    email_client = models.EmailField(default='unknow@example.com')
    date_commande = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"commande de {self.quantite} x {self.plat.nom}"