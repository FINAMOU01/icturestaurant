
from django.shortcuts import render, redirect, get_object_or_404
from .models import  Menu ,commande
from Restaurant .models import Plat 
from .forms import commandeForm
from django.contrib import messages


def afficher_menu(request):
    menus = Menu.objects.all()
    return render(request, 'restaurant/menu.html', {'menus': menus})

def commande_view(request, plat_id):
    plat = get_object_or_404(Plat, id=plat_id)

    if request.method == 'POST':
        form = commandeForm(request.POST)
        if form.is_valid():
            commande.objects.create(
                plat=plat,
                nom_client=form.cleaned_data['nom_client'],
                email_client=form.cleaned_data['email_client'],
                quantite=form.cleaned_data['quantite']
                
            )
            messages.success(request, 'Commande réussie !')
            return redirect('menu')
    else:
        form = commandeForm()

    return render(request, 'commande.html', {'form': form, 'plat': plat})