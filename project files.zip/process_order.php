<?php
// Replace with your Hostinger Titan email settings
$to = 'your_admin_email@yourdomain.com'; // Admin's email
$from = $_POST['email']; // Customer's email
$subject = 'New Order from ' . $_POST['name'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $message = "Name: $name\nEmail: $email\nRole: $role";

    // Email headers
    $headers = "From: $from\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/plain; charset=utf-8\r\n";

    // Send email
    if (mail($to, $subject, $message, $headers)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error sending email']);
    }
}
